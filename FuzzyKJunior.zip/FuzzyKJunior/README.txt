Sistemas Inteligentes - s73
--> Trabalho de Sistemas Fuzzy
- Caroline Rosa
- Juliana Rodrigues
- Rafael Felix

--> Instruções para execução
1. Ter a biblioteca skfuzzy instalada
2. Abrir a scene KJunior no v-rep e executá-la
3. Rodar o arquivo KJunior.py
4. O script começará a executar automaticamente e irá finalizar quando o robô atingir o laptop

OBS: Utilizar Python3 64 bits (caso seja 32 bits, precisa utilizar outra dll)