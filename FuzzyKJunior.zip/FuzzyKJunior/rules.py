
#########################################################################################################################
#   Sistemas Inteligentes - s73
#   - Caroline Rosa
#   - Juliana Rodrigues
#   - Rafael Felix
#########################################################################################################################


import numpy as np
import skfuzzy as fuzz
import skfuzzy.control as ctrl

def fuzzy():
    s_names = ['left', 'centerLeft', 'centerRight', 'right']
    w_names = ['leftWheel', 'rightWheel']

    # Mapeando os sensores
    sensors = {s: ctrl.Antecedent(np.arange(0, 2000, 1), s) for s in s_names}

    # Mapeando os motores
    wheels = {w: ctrl.Consequent(np.arange(-5, 5, 0.1), w) for w in w_names}

    # Mapeando a orientação
    orientation = ctrl.Antecedent(np.arange(-181, 181, 0.1), 'orientation')

    # Definindo as variáveis linguísticas dos sensores
    for s in sensors.values():
        s['far'] = fuzz.trapmf(s.universe, [0, 0, 90, 100])
        s['near'] = fuzz.trapmf(s.universe, [100, 200, 900, 1200])
        s['very-near'] = fuzz.trapmf(s.universe, [900, 1000, 2000, 2000])

    # Definindo as variáveis linguísticas dos motores
    for w in wheels.values():
        w['fastReverse'] = fuzz.trapmf(w.universe, [-5,-5,-3.5,-1])
        w['slowReverse'] = fuzz.trapmf(w.universe, [-4,-1.5,0,0])
        w['stopped'] = fuzz.trapmf(w.universe, [-0.2,-0.1,0.1,0.2])
        w['slowForward'] = fuzz.trapmf(w.universe, [ 0,0,1.5,4])
        w['fastForward'] = fuzz.trapmf(w.universe, [ 1,3.5,5,5])

    # Definindo as variáveis linguísticas da orientação
    orientation['left'] = fuzz.trimf( orientation.universe, [-181, -40, 0])
    orientation['center'] = fuzz.trapmf(orientation.universe, [-60, -20, 20, 60])
    orientation['right'] = fuzz.trimf( orientation.universe, [0, 40, 181])

    wheelRules = [

        # Orientation = center ###############################################
        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['near'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['near'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['near'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['center'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        # Orientation = left #################################################
        ctrl.Rule(orientation['left'] & \
        sensors['left']['near'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['near'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['left'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        # Orientation = right #################################################
        ctrl.Rule(orientation['right'] & \
        sensors['left']['near'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['near'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['slowForward']]),

        ctrl.Rule(orientation['right'] & \
        sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowForward'], wheels['rightWheel']['fastForward']]),

        # Casos muito perto #####################################################
        ctrl.Rule(sensors['left']['very-near'] & sensors['centerLeft']['very-near'] & sensors['centerRight']['very-near'] & sensors['right']['very-near'], \
        [wheels['leftWheel']['slowReverse'], wheels['rightWheel']['slowReverse']]),

        ctrl.Rule(sensors['left']['very-near'] & sensors['centerLeft']['very-near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['stopped']]),

        ctrl.Rule(sensors['left']['very-near'] & sensors['centerLeft']['very-near'] & sensors['centerRight']['near'] & sensors['right']['near'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['stopped']]),

        ctrl.Rule(sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['very-near'] & sensors['right']['very-near'], \
        [wheels['leftWheel']['stopped'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(sensors['left']['near'] & sensors['centerLeft']['near'] & sensors['centerRight']['very-near'] & sensors['right']['very-near'], \
        [wheels['leftWheel']['stopped'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(sensors['left']['near'] & sensors['centerLeft']['very-near'] & sensors['centerRight']['very-near'] & sensors['right']['near'], \
        [wheels['leftWheel']['slowReverse'], wheels['rightWheel']['slowReverse']]),

        ctrl.Rule(sensors['left']['far'] & sensors['centerLeft']['very-near'] & sensors['centerRight']['very-near'] & sensors['right']['far'], \
        [wheels['leftWheel']['slowReverse'], wheels['rightWheel']['slowReverse']]),

        ctrl.Rule(sensors['left']['very-near'] & sensors['centerLeft']['near'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['stopped']]),

        ctrl.Rule(sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['near'] & sensors['right']['very-near'], \
        [wheels['leftWheel']['stopped'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(sensors['left']['very-near'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['stopped']]),

        ctrl.Rule(sensors['left']['far'] & sensors['centerLeft']['far'] & sensors['centerRight']['far'] & sensors['right']['very-near'], \
        [wheels['leftWheel']['stopped'], wheels['rightWheel']['fastForward']]),

        ctrl.Rule(sensors['left']['near'] & sensors['centerLeft']['near'] & sensors['centerRight']['near'] & sensors['right']['far'], \
        [wheels['leftWheel']['fastForward'], wheels['rightWheel']['stopped']]),

        ctrl.Rule(sensors['left']['far'] & sensors['centerLeft']['near'] & sensors['centerRight']['near'] & sensors['right']['near'], \
        [wheels['leftWheel']['stopped'], wheels['rightWheel']['fastForward']]),

        
    ]

    wheelControl = ctrl.ControlSystem(wheelRules)
    wheelFuzzy = ctrl.ControlSystemSimulation(wheelControl)

    return wheelFuzzy
